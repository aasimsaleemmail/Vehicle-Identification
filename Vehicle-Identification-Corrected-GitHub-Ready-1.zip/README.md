# Vehicle Identification
Corrected Android starter project.
The layout file is in the correct Android resource folder:
app/src/main/res/layout/activity_main.xml
